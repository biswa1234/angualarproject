import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { FormGroup } from "@angular/forms";
import { FormControl } from "@angular/forms";
import { Validators } from "@angular/forms";
import { LoginService } from "src/app/login.service";
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-forgotpassword',
  templateUrl: './forgotpassword.component.html',
  styleUrls: ['./forgotpassword.component.css']
})
export class ForgotpasswordComponent implements OnInit {
form = new FormGroup({
    email: new FormControl('', [Validators.required, Validators.email])
  })
  constructor(private router:Router,private toastr: ToastrService, private loginService: LoginService) { }

  ngOnInit() {
  }

   backLogin() {
    this.router.navigate(['/login']);
  }
 forgotpasswordClick() {
    console.log(JSON.stringify(this.form.value));
   this.loginService.forgotPassword(JSON.stringify(this.form.value)).subscribe((res) => {
        console.log(res);
        if (res.code === 200) {
          this.form.reset();
          this.toastr.success('Success', res.success);
        } else if (res.code === 204) {
          this.toastr.warning('Warning', res.success);
        } else {
          this.toastr.error('Error', 'Failed to send mail');
        }
      });
   
  }
}
