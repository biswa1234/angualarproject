export class Register{
    username: String;
    password: String;
    email: String;

}