import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { FormGroup } from "@angular/forms";
import { FormControl } from "@angular/forms";
import { Validators } from "@angular/forms";
import { ToastrService } from 'ngx-toastr';
import { LoginService } from "src/app/login.service";
import { Register } from "src/app/model/register";
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {


  register: Register;
  form = new FormGroup({
    name: new FormControl('', Validators.required),
    email: new FormControl('', [Validators.required, Validators.email]),
    password: new FormControl('', [Validators.required, Validators.minLength(6)]),
    cnfpassword: new FormControl('', [Validators.required, Validators.minLength(6)])
  })

  constructor(private router: Router,
    private toastr: ToastrService, private loginService: LoginService) {

  }

  ngOnInit() {

  }

  registerClick() {
    console.log("pass: " + this.form.value.password + " cnfpass: " + this.form.value.cnfpassword)
    if (this.form.value.password === this.form.value.cnfpassword) {
      console.log(JSON.stringify(this.form.value));
      this.register = {
        "username": this.form.value.name,
        "password": this.form.value.password,
        "email": this.form.value.email
      };

      this.loginService.registerNewUser(JSON.stringify(this.register)).subscribe((res) => {
        console.log(res);
        if (res.code === 200) {
          this.form.reset();
          this.toastr.success('Success', res.success);
        } else if (res.code === 204) {
          this.toastr.warning('Warning', res.success);
        } else {
          this.toastr.error('Error', 'Failed to Register');
        }
      });

    } else {
      this.toastr.error('MissMatch password', 'Confirm password doesnot match');
    }

  }

  backLogin() {
    this.router.navigate(['/login']);
  }
}
